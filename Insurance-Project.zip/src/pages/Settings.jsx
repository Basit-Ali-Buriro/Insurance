import React, { useState } from 'react';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

export default function Settings({ user, onProfileUpdate }) {
  const toast = useToast();
  const [profile,   setProfile]   = useState({ name: user?.name || '', username: user?.username || '' });
  const [pwdForm,   setPwdForm]   = useState({ currentPassword:'', newPassword:'', confirmPassword:'' });
  const [savingP,   setSavingP]   = useState(false);
  const [savingPwd, setSavingPwd] = useState(false);
  const [pwdErrors, setPwdErrors] = useState({});
  const [showPwd,   setShowPwd]   = useState({ curr:false, new:false, confirm:false });

  const handleSaveProfile = async () => {
    if (!profile.name.trim() || !profile.username.trim()) {
      toast('Name and username are required','error'); return;
    }
    setSavingP(true);
    try {
      const res = await api.updateProfile({ id: user.id, name: profile.name.trim(), username: profile.username.trim() });
      if (res.ok) {
        toast('Profile updated successfully','success');
        onProfileUpdate?.({ name: profile.name.trim(), username: profile.username.trim() });
      } else toast(res.error || 'Update failed','error');
    } finally { setSavingP(false); }
  };

  const handleChangePassword = async () => {
    const e = {};
    if (!pwdForm.currentPassword)   e.currentPassword   = 'Required';
    if (!pwdForm.newPassword)        e.newPassword        = 'Required';
    if (pwdForm.newPassword.length < 6) e.newPassword    = 'Minimum 6 characters';
    if (pwdForm.newPassword !== pwdForm.confirmPassword) e.confirmPassword = 'Passwords do not match';
    if (Object.keys(e).length) { setPwdErrors(e); return; }
    setSavingPwd(true);
    try {
      const res = await api.changePassword({ id: user.id, currentPassword: pwdForm.currentPassword, newPassword: pwdForm.newPassword });
      if (res.ok) {
        toast('Password changed successfully','success');
        setPwdForm({ currentPassword:'', newPassword:'', confirmPassword:'' });
        setPwdErrors({});
      } else {
        toast(res.error || 'Failed to change password','error');
      }
    } finally { setSavingPwd(false); }
  };

  const toggle = (k) => setShowPwd(v => ({ ...v, [k]: !v[k] }));
  const setPwd = (k, v) => { setPwdForm(f=>({...f,[k]:v})); setPwdErrors(e=>({...e,[k]:undefined})); };

  const PwdInput = ({ fieldKey, label, pwdKey }) => (
    <div className="form-group">
      <label className="form-label required">{label}</label>
      <div style={{ position:'relative' }}>
        <input
          id={`settings-${fieldKey}`}
          type={showPwd[pwdKey] ? 'text':'password'}
          className={`form-input${pwdErrors[fieldKey]?' error':''}`}
          value={pwdForm[fieldKey]}
          onChange={e => setPwd(fieldKey, e.target.value)}
          style={{ paddingRight:40 }}
        />
        <button type="button" onClick={()=>toggle(pwdKey)} tabIndex={-1}
          style={{ position:'absolute',right:10,top:'50%',transform:'translateY(-50%)',background:'none',border:'none',cursor:'pointer',color:'var(--text-muted)',fontSize:'0.85rem' }}>
          {showPwd[pwdKey]?'🙈':'👁'}
        </button>
      </div>
      {pwdErrors[fieldKey] && <span className="form-error">{pwdErrors[fieldKey]}</span>}
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Settings</h1><p className="page-subtitle">Manage your account details</p></div>
      </div>

      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:20, maxWidth:860 }}>
        {/* Profile */}
        <div className="card">
          <h3 style={{ marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
            <span>👤</span> Profile Information
          </h3>
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <div className="form-group">
              <label className="form-label required" htmlFor="settings-name">Display Name</label>
              <input id="settings-name" className="form-input" value={profile.name} onChange={e=>setProfile(p=>({...p,name:e.target.value}))} />
            </div>
            <div className="form-group">
              <label className="form-label required" htmlFor="settings-username">Username</label>
              <input id="settings-username" className="form-input" value={profile.username} onChange={e=>setProfile(p=>({...p,username:e.target.value}))} />
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <span className="form-label" style={{ marginBottom:0 }}>Role:</span>
              <span className={`role-badge ${user?.role}`}>{user?.role}</span>
            </div>
            <button id="btn-save-profile" className="btn btn-primary btn-sm" onClick={handleSaveProfile} disabled={savingP} style={{ alignSelf:'flex-end' }}>
              {savingP ? <><span className="spinner"/> Saving…</> : 'Save Profile'}
            </button>
          </div>
        </div>

        {/* Change Password */}
        <div className="card">
          <h3 style={{ marginBottom:16, display:'flex', alignItems:'center', gap:8 }}>
            <span>🔐</span> Change Password
          </h3>
          <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
            <PwdInput fieldKey="currentPassword" label="Current Password" pwdKey="curr" />
            <PwdInput fieldKey="newPassword"      label="New Password"     pwdKey="new"  />
            <PwdInput fieldKey="confirmPassword"  label="Confirm Password" pwdKey="confirm" />
            <button id="btn-change-password" className="btn btn-primary btn-sm" onClick={handleChangePassword} disabled={savingPwd} style={{ alignSelf:'flex-end' }}>
              {savingPwd ? <><span className="spinner"/> Saving…</> : 'Change Password'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
