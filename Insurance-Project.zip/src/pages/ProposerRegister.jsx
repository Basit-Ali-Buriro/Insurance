import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import SearchableDropdown from '../components/SearchableDropdown.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const EMPTY = { proposal_no:'', holder_name:'', premium:'', pr_no:'', pr_date:'', amount_type:'cash', requirements:'', sr_id:null, sm_id:null, ssm_id:null, status:'not_ok' };

export default function ProposerRegister({ onNavigate }) {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [srs,  setSRs]  = useState([]);
  const [sms,  setSMs]  = useState([]);
  const [ssms, setSSMs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');
  const [modal,   setModal]   = useState({ open:false, mode:'create', data:EMPTY });
  const [confirm, setConfirm] = useState({ open:false, id:null, type:'delete' });
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});
  const [convertId, setConvertId] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r, sr, sm, ssm] = await Promise.all([api.listProposers(), api.listSR(), api.listSM(), api.listSSM()]);
      setRows(r); setSRs(sr); setSMs(sm); setSSMs(ssm);
    } catch { toast('Failed to load data','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const srOpts  = srs.map(s  => ({ value:s.id, label:`${s.sr_code} — ${s.sr_name}`   }));
  const smOpts  = sms.map(s  => ({ value:s.id, label:`${s.sm_code} — ${s.sm_name}`   }));
  const ssmOpts = ssms.map(s => ({ value:s.id, label:`${s.ssm_code} — ${s.ssm_name}` }));

  const filtered = rows.filter(r =>
    !search ||
    r.holder_name?.toLowerCase().includes(search.toLowerCase()) ||
    r.proposal_no?.toLowerCase().includes(search.toLowerCase())
  );

  const validate = (d) => {
    const e = {};
    if (!d.proposal_no.trim()) e.proposal_no = 'Required';
    if (!d.holder_name.trim()) e.holder_name = 'Required';
    if (!d.premium || isNaN(d.premium)) e.premium = 'Valid number required';
    return e;
  };

  const set = (k, v) => { setModal(m=>({...m, data:{...m.data,[k]:v}})); setErrors(e=>({...e,[k]:undefined})); };

  const handleSave = async () => {
    const e = validate(modal.data);
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    // Check if status switched to OK — prompt conversion
    const willConvert = modal.data.status === 'ok' && modal.mode === 'edit';
    try {
      const res = modal.mode==='create' ? await api.createProposer(modal.data) : await api.updateProposer(modal.data);
      if (res.ok) {
        toast(`Proposal ${modal.mode==='create'?'created':'updated'}`, 'success');
        setModal(m=>({...m,open:false}));
        load();
        if (willConvert && !modal.data.converted_to_policy) setConvertId(modal.data.id);
      } else toast(res.error||'Save failed','error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    const res = await api.deleteProposer(confirm.id);
    if (res.ok) { toast('Proposal deleted','success'); load(); }
    else toast(res.error||'Delete failed','error');
    setConfirm({open:false,id:null,type:'delete'});
  };

  const handleConvert = async () => {
    const res = await api.convertProposerToPolicy(convertId);
    if (res.ok) {
      toast('Proposal converted. Complete the policy record.','success');
      setConvertId(null);
      onNavigate('policy');
    } else {
      toast(res.error||'Conversion failed','error');
      setConvertId(null);
    }
  };

  const columns = [
    { key:'proposal_no',  label:'Proposal No' },
    { key:'holder_name',  label:'Holder Name' },
    { key:'premium',      label:'Premium', render: v=>`Rs. ${Number(v).toLocaleString()}` },
    { key:'pr_no',        label:'PR No' },
    { key:'pr_date',      label:'PR Date' },
    { key:'amount_type',  label:'Type', render: v=><span className="badge badge-active" style={{textTransform:'capitalize'}}>{v}</span> },
    { key:'sr_code',      label:'SR Code' },
    { key:'sm_code',      label:'SM Code' },
    { key:'status',       label:'Status', render: v=><span className={`badge badge-${v}`}>{v==='not_ok'?'Not OK':'OK'}</span> },
    { key:'converted_to_policy', label:'Converted', render: v=><span className={`badge ${v?'badge-active':'badge-inactive'}`}>{v?'Yes':'No'}</span> },
  ];

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Proposer Register</h1><p className="page-subtitle">Manage insurance proposals</p></div>
        <div className="page-actions">
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="prop-search" className="search-input" placeholder="Search by name or proposal no…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <button id="btn-create-proposer" className="btn btn-primary btn-sm" onClick={()=>setModal({open:true,mode:'create',data:{...EMPTY}})}>+ Add Proposal</button>
        </div>
      </div>

      <DataTable columns={columns} rows={filtered} loading={loading}
        actions={row=><>
          <button className="btn btn-ghost btn-sm" onClick={()=>setModal({open:true,mode:'edit',data:{...row}})}>✏️</button>
          <button className="btn btn-danger btn-sm" onClick={()=>setConfirm({open:true,id:row.id,type:'delete'})}>🗑</button>
          {!row.converted_to_policy && row.status==='ok' && (
            <button className="btn btn-success btn-sm" onClick={()=>setConvertId(row.id)}>→ Policy</button>
          )}
        </>}
      />

      {/* Form Modal */}
      <Modal open={modal.open} onClose={()=>setModal(m=>({...m,open:false}))}
        title={modal.mode==='create'?'Add Proposal':'Edit Proposal'} size="lg"
        footer={<>
          <button className="btn btn-secondary btn-sm" onClick={()=>setModal(m=>({...m,open:false}))}>Cancel</button>
          <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>{saving?<span className="spinner"/>:'Save'}</button>
        </>}
      >
        <div className="form-grid form-grid-2" style={{gap:14}}>
          <div className="form-group">
            <label className="form-label required">Proposal No</label>
            <input className={`form-input${errors.proposal_no?' error':''}`} value={modal.data.proposal_no} onChange={e=>set('proposal_no',e.target.value)} />
            {errors.proposal_no&&<span className="form-error">{errors.proposal_no}</span>}
          </div>
          <div className="form-group">
            <label className="form-label required">Holder Name</label>
            <input className={`form-input${errors.holder_name?' error':''}`} value={modal.data.holder_name} onChange={e=>set('holder_name',e.target.value)} />
            {errors.holder_name&&<span className="form-error">{errors.holder_name}</span>}
          </div>
          <div className="form-group">
            <label className="form-label required">Amount / Premium</label>
            <input type="number" className={`form-input${errors.premium?' error':''}`} value={modal.data.premium} onChange={e=>set('premium',e.target.value)} />
            {errors.premium&&<span className="form-error">{errors.premium}</span>}
          </div>
          <div className="form-group">
            <label className="form-label">PR No</label>
            <input className="form-input" value={modal.data.pr_no} onChange={e=>set('pr_no',e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">PR Date</label>
            <input type="date" className="form-input" value={modal.data.pr_date} onChange={e=>set('pr_date',e.target.value)} />
          </div>
          <div className="form-group">
            <label className="form-label">Amount Type</label>
            <select className="form-select" value={modal.data.amount_type} onChange={e=>set('amount_type',e.target.value)}>
              <option value="cash">Cash</option><option value="cheque">Cheque</option>
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">SR</label>
            <SearchableDropdown id="prop-sr" options={srOpts} value={modal.data.sr_id} onChange={v=>set('sr_id',v)} placeholder="Select SR…"/>
          </div>
          <div className="form-group">
            <label className="form-label">SM</label>
            <SearchableDropdown id="prop-sm" options={smOpts} value={modal.data.sm_id} onChange={v=>set('sm_id',v)} placeholder="Select SM…"/>
          </div>
          <div className="form-group">
            <label className="form-label">SSM</label>
            <SearchableDropdown id="prop-ssm" options={ssmOpts} value={modal.data.ssm_id} onChange={v=>set('ssm_id',v)} placeholder="Select SSM…"/>
          </div>
          <div className="form-group">
            <label className="form-label">Status</label>
            <select className="form-select" value={modal.data.status} onChange={e=>set('status',e.target.value)}>
              <option value="not_ok">Not OK</option><option value="ok">OK</option>
            </select>
          </div>
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Requirements / Notes</label>
            <textarea className="form-textarea" value={modal.data.requirements} onChange={e=>set('requirements',e.target.value)} rows={3}/>
          </div>
        </div>
      </Modal>

      {/* Convert to Policy confirm */}
      <ConfirmDialog open={!!convertId} onClose={()=>setConvertId(null)} onConfirm={handleConvert} danger={false}
        title="Convert to Policy?" message="Convert this proposal to a Policy Record? You will be taken to the Policy Register to complete the remaining fields." />

      <ConfirmDialog open={confirm.open&&confirm.type==='delete'} onClose={()=>setConfirm({open:false,id:null,type:'delete'})} onConfirm={handleDelete}
        title="Delete Proposal" message="Are you sure? This action cannot be undone." />
    </div>
  );
}
