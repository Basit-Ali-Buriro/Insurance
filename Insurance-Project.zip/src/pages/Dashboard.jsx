import React, { useEffect, useState, useCallback } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import KpiCard    from '../components/KpiCard.jsx';
import DonutChart from '../components/DonutChart.jsx';
import api        from '../lib/api.js';
import { useToast } from '../components/Toast.jsx';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

function fmt(n) { return `Rs. ${Number(n||0).toLocaleString()}`; }
function trendPct(curr, prev) {
  if (!prev) return curr > 0 ? 100 : 0;
  return ((curr - prev) / prev) * 100;
}

export default function Dashboard({ onNavigate }) {
  const toast = useToast();
  const [kpis,    setKpis]    = useState(null);
  const [loading, setLoading] = useState(true);
  const [dueRange, setDueRange] = useState(30);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api.dashboardKpis();
      setKpis(data);
    } catch (err) {
      toast('Failed to load dashboard data', 'error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleSaveTarget = async (key, value) => {
    await api.saveTarget({ key, value });
    toast('Target updated', 'success');
    load();
  };

  const handleDownloadBackup = async () => {
    const res = await api.downloadBackup();
    if (res?.ok) toast('Backup saved successfully', 'success');
    else if (res?.ok === false) toast('Backup cancelled', 'info');
    else toast('Backup failed', 'error');
  };

  const monthlyChart = (kpis?.monthlyChart || []).map((m, i) => ({
    name: MONTHS[i], value: m.premium,
  }));

  const dueCount = dueRange === 7 ? kpis?.due7 : dueRange === 15 ? kpis?.due15 : kpis?.due30;

  const monthlyTarget = parseFloat(kpis?.config?.monthly_target || 0);
  const yearlyTarget  = parseFloat(kpis?.config?.yearly_target  || 0);

  const prevPrem = kpis?.prevMonthPrem || 0;
  const currPrem = kpis?.currentMonthPrem || 0;

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
      {/* Header */}
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-subtitle">Overview of your insurance business performance</p>
        </div>
        <div className="page-actions">
          <button className="btn btn-secondary btn-sm" id="btn-download-backup" onClick={handleDownloadBackup}>
            💾 Download Backup
          </button>
        </div>
      </div>

      {/* Row 1 — Core KPI Cards */}
      <div className="section-row cols-4">
        <KpiCard title="Total Policies"   value={kpis?.totalPolicies}  icon="📄" loading={loading}
          trend={trendPct(currPrem, prevPrem)} onClick={() => onNavigate('policy')} />
        <KpiCard title="Total Proposals"  value={kpis?.totalProposals} icon="📋" loading={loading}
          onClick={() => onNavigate('proposer')} />
        <KpiCard title="Total SRs"        value={kpis?.totalSRs}       icon="👤" loading={loading}
          onClick={() => onNavigate('sr')} />
        <KpiCard title="Total SMs"        value={kpis?.totalSMs}       icon="👥" loading={loading}
          onClick={() => onNavigate('sm')} />
      </div>

      {/* Row 2 — Performance & Alert Widgets */}
      <div className="section-row cols-3">
        {/* SSMs */}
        <KpiCard title="Total SSMs" value={kpis?.totalSSMs} icon="🏆" loading={loading}
          onClick={() => onNavigate('ssm')} />

        {/* Policies Due Soon */}
        <div className="card">
          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:12 }}>
            <span className="stat-label">Policies Due Soon</span>
            <div className="toggle-group">
              {[7,15,30].map(d => (
                <button key={d} className={`toggle-btn${dueRange===d?' active':''}`}
                  id={`btn-due-${d}`} onClick={() => setDueRange(d)}>{d} Days</button>
              ))}
            </div>
          </div>
          <div className="stat-number" style={{ cursor:'pointer', color:'var(--accent-orange)' }}
            onClick={() => onNavigate('notifications')}>
            {loading ? '—' : (dueCount ?? 0)}
          </div>
          <div style={{ marginTop:10, display:'flex', flexDirection:'column', gap:4 }}>
            {[['7 Days', kpis?.due7], ['15 Days', kpis?.due15], ['30 Days', kpis?.due30]].map(([label, val]) => (
              <div key={label} style={{ display:'flex', justifyContent:'space-between', fontSize:'0.75rem', color:'var(--text-muted)' }}>
                <span>Due in {label}</span>
                <span style={{ fontWeight:600, color:'var(--text-secondary)' }}>{loading ? '—' : (val ?? 0)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Financial KPIs */}
        <div className="card">
          <span className="stat-label" style={{ display:'block', marginBottom:12 }}>Financial KPIs</span>
          <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
            <div>
              <div style={{ fontSize:'0.72rem', color:'var(--text-muted)' }}>Current Month Premium</div>
              <div style={{ fontSize:'1.2rem', fontWeight:700, color:'var(--accent-green)', marginTop:2 }}>
                {loading ? '—' : fmt(currPrem)}
              </div>
              {!loading && (
                <span className={`trend ${currPrem >= prevPrem ? 'up':'down'}`} style={{ fontSize:'0.7rem' }}>
                  {currPrem >= prevPrem ? '↑' : '↓'} {Math.abs(trendPct(currPrem,prevPrem)).toFixed(1)}% vs last month
                </span>
              )}
            </div>
            <hr className="separator" style={{ margin:'4px 0' }} />
            <div>
              <div style={{ fontSize:'0.72rem', color:'var(--text-muted)' }}>Year-to-Date Premium</div>
              <div style={{ fontSize:'1.2rem', fontWeight:700, color:'var(--accent)', marginTop:2 }}>
                {loading ? '—' : fmt(kpis?.ytdPrem)}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Row 3 — Monthly Bar Chart */}
      <div className="card">
        <div style={{ marginBottom:14, fontWeight:600, fontSize:'0.85rem', color:'var(--text-secondary)' }}>
          Monthly Premium — {new Date().getFullYear()}
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={monthlyChart} margin={{ top:4, right:8, left:0, bottom:0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" vertical={false} />
            <XAxis dataKey="name" tick={{ fill:'var(--text-muted)', fontSize:11 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fill:'var(--text-muted)', fontSize:11 }} axisLine={false} tickLine={false}
              tickFormatter={v => v >= 1000 ? `${(v/1000).toFixed(0)}k` : v} />
            <Tooltip
              formatter={v => [fmt(v), 'Premium']}
              contentStyle={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, fontSize:'0.75rem' }}
              cursor={{ fill:'rgba(59,130,246,0.06)' }}
            />
            <Bar dataKey="value" fill="var(--accent)" radius={[4,4,0,0]} maxBarSize={32} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Row 4 — Target Donuts */}
      <div className="section-row cols-2">
        <DonutChart
          id="monthly" title="Monthly Target"
          achieved={currPrem} target={monthlyTarget}
          color="var(--accent)"
          onEditTarget={v => handleSaveTarget('monthly_target', v)}
        />
        <DonutChart
          id="yearly" title="Yearly Target"
          achieved={kpis?.ytdPrem || 0} target={yearlyTarget}
          color="var(--accent-purple)"
          onEditTarget={v => handleSaveTarget('yearly_target', v)}
        />
      </div>

      {/* Row 5 — Insights */}
      <div className="section-row cols-3">
        {/* Renewals */}
        <div className="card kpi-clickable" onClick={() => onNavigate('policy')} id="widget-renewals">
          <span className="stat-label">Approaching Renewals</span>
          <div className="stat-number" style={{ color:'var(--accent-orange)', marginTop:8 }}>
            {loading ? '—' : (kpis?.renewals ?? 0)}
          </div>
          <p style={{ fontSize:'0.72rem', color:'var(--text-muted)', marginTop:6 }}>
            Policies with Last Paid Date &gt; 11 months ago
          </p>
        </div>

        {/* Top SR */}
        <div className="card" id="widget-top-sr">
          <span className="stat-label">Top SR — This Month</span>
          {loading || !kpis?.topSR ? (
            <div style={{ color:'var(--text-muted)', fontSize:'0.8rem', marginTop:10 }}>No data yet</div>
          ) : (
            <>
              <div style={{ fontWeight:700, fontSize:'1rem', marginTop:8 }}>{kpis.topSR.sr_name}</div>
              <div style={{ fontSize:'0.75rem', color:'var(--text-muted)', marginTop:2 }}>Code: {kpis.topSR.sr_code}</div>
              <div style={{ fontSize:'0.85rem', color:'var(--accent-green)', fontWeight:600, marginTop:6 }}>
                {fmt(kpis.topSR.biz)}
              </div>
            </>
          )}
        </div>

        {/* Top SM */}
        <div className="card" id="widget-top-sm">
          <span className="stat-label">Top SM — This Month</span>
          {loading || !kpis?.topSM ? (
            <div style={{ color:'var(--text-muted)', fontSize:'0.8rem', marginTop:10 }}>No data yet</div>
          ) : (
            <>
              <div style={{ fontWeight:700, fontSize:'1rem', marginTop:8 }}>{kpis.topSM.sm_name}</div>
              <div style={{ fontSize:'0.75rem', color:'var(--text-muted)', marginTop:2 }}>Code: {kpis.topSM.sm_code}</div>
              <div style={{ fontSize:'0.85rem', color:'var(--accent-green)', fontWeight:600, marginTop:6 }}>
                {fmt(kpis.topSM.biz)}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
