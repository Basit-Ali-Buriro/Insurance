import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const EMPTY = { name:'', username:'', password:'', role:'admin', status:'active' };

export default function UsersPage({ user: currentUser }) {
  const toast = useToast();
  const [rows,    setRows]    = useState([]);
  const [loading, setLoading] = useState(true);
  const [modal,   setModal]   = useState({ open:false, mode:'create', data:EMPTY });
  const [confirm, setConfirm] = useState({ open:false, id:null });
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});
  const [showPwd, setShowPwd] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows(await api.listUsers()); }
    catch { toast('Failed to load users','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const validate = (d, mode) => {
    const e = {};
    if (!d.name.trim())     e.name     = 'Required';
    if (!d.username.trim()) e.username = 'Required';
    if (mode==='create' && !d.password) e.password = 'Required';
    if (d.password && d.password.length < 6) e.password = 'Min 6 characters';
    return e;
  };

  const set = (k, v) => { setModal(m=>({...m, data:{...m.data,[k]:v}})); setErrors(e=>({...e,[k]:undefined})); };

  const handleSave = async () => {
    const e = validate(modal.data, modal.mode);
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    try {
      const res = modal.mode==='create' ? await api.createUser(modal.data) : await api.updateUser(modal.data);
      if (res.ok) {
        toast(`User ${modal.mode==='create'?'created':'updated'}`, 'success');
        setModal(m=>({...m,open:false}));
        load();
      } else toast(res.error||'Save failed','error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    const res = await api.deleteUser(confirm.id);
    if (res.ok) { toast('User deleted','success'); load(); }
    else toast(res.error||'Cannot delete this account','error');
    setConfirm({open:false,id:null});
  };

  const columns = [
    { key:'user_id',   label:'ID' },
    { key:'name',      label:'Name' },
    { key:'username',  label:'Username' },
    { key:'role',      label:'Role',   render: v=><span className={`role-badge ${v}`}>{v}</span> },
    { key:'status',    label:'Status', render: v=><span className={`badge badge-${v}`}>{v}</span> },
    { key:'created_at',label:'Created' },
  ];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Users</h1>
          <p className="page-subtitle">Manage application user accounts — Developer only</p>
        </div>
        <button id="btn-create-user" className="btn btn-primary btn-sm" onClick={()=>setModal({open:true,mode:'create',data:{...EMPTY},setShowPwd:false})}>
          + Add User
        </button>
      </div>

      <DataTable columns={columns} rows={rows} loading={loading}
        actions={row=><>
          <button className="btn btn-ghost btn-sm" onClick={()=>{ setShowPwd(false); setModal({open:true,mode:'edit',data:{...row,password:''}}); }}>✏️</button>
          {row.role !== 'developer' && (
            <button className="btn btn-danger btn-sm" onClick={()=>setConfirm({open:true,id:row.user_id})}>🗑</button>
          )}
        </>}
      />

      <Modal open={modal.open} onClose={()=>setModal(m=>({...m,open:false}))}
        title={modal.mode==='create'?'Add User':'Edit User'} size="md"
        footer={<>
          <button className="btn btn-secondary btn-sm" onClick={()=>setModal(m=>({...m,open:false}))}>Cancel</button>
          <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>{saving?<span className="spinner"/>:'Save'}</button>
        </>}
      >
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {[['name','Display Name',true,'text'],['username','Username',true,'text']].map(([k,label,req,type])=>(
            <div key={k} className="form-group">
              <label className={`form-label${req?' required':''}`}>{label}</label>
              <input type={type} className={`form-input${errors[k]?' error':''}`} value={modal.data[k]||''} onChange={e=>set(k,e.target.value)} />
              {errors[k]&&<span className="form-error">{errors[k]}</span>}
            </div>
          ))}
          <div className="form-group">
            <label className="form-label" style={{display:'flex',justifyContent:'space-between'}}>
              {modal.mode==='create'?<span className="required" style={{fontWeight:600,fontSize:'0.75rem',color:'var(--text-secondary)',letterSpacing:'0.03em'}}>Password</span>:<span style={{fontWeight:600,fontSize:'0.75rem',color:'var(--text-secondary)',letterSpacing:'0.03em'}}>Password</span>}
              {modal.mode==='edit'&&<span style={{fontSize:'0.68rem',color:'var(--text-muted)'}}>Leave blank to keep current</span>}
            </label>
            <div style={{position:'relative'}}>
              <input
                id="user-password"
                type={showPwd?'text':'password'}
                className={`form-input${errors.password?' error':''}`}
                value={modal.data.password||''}
                onChange={e=>set('password',e.target.value)}
                placeholder={modal.mode==='edit'?'Leave blank to keep unchanged':'Enter password'}
                style={{paddingRight:40}}
              />
              <button type="button" onClick={()=>setShowPwd(v=>!v)} tabIndex={-1}
                style={{position:'absolute',right:10,top:'50%',transform:'translateY(-50%)',background:'none',border:'none',cursor:'pointer',color:'var(--text-muted)',fontSize:'0.85rem'}}>
                {showPwd?'🙈':'👁'}
              </button>
            </div>
            {errors.password&&<span className="form-error">{errors.password}</span>}
          </div>
          <div className="form-grid form-grid-2" style={{gap:14}}>
            <div className="form-group">
              <label className="form-label">Role</label>
              <select className="form-select" value={modal.data.role} onChange={e=>set('role',e.target.value)}
                disabled={modal.data.role==='developer'}>
                <option value="admin">Admin</option>
                <option value="developer">Developer</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Status</label>
              <select className="form-select" value={modal.data.status} onChange={e=>set('status',e.target.value)}>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={confirm.open} onClose={()=>setConfirm({open:false,id:null})} onConfirm={handleDelete}
        title="Delete User" message="Are you sure you want to delete this account? This action cannot be undone." />
    </div>
  );
}
