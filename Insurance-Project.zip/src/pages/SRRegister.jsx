import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import SearchableDropdown from '../components/SearchableDropdown.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const EMPTY = { sr_code:'', sr_name:'', address:'', cnic:'', contact_1:'', contact_2:'', sm_id:null, ssm_id:null, am_id:null, status:'active' };

export default function SRRegister() {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [sms,  setSMs]  = useState([]);
  const [ssms, setSSMs] = useState([]);
  const [ams,  setAMs]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [modal,   setModal]   = useState({ open:false, mode:'create', data:EMPTY });
  const [confirm, setConfirm] = useState({ open:false, id:null });
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r,sm,ssm,am] = await Promise.all([api.listSR(), api.listSM(), api.listSSM(), api.listAM()]);
      setRows(r); setSMs(sm); setSSMs(ssm); setAMs(am);
    } catch { toast('Failed to load SR data','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const smOpts  = sms.map(s  => ({ value:s.id, label:`${s.sm_code} — ${s.sm_name}`   }));
  const ssmOpts = ssms.map(s => ({ value:s.id, label:`${s.ssm_code} — ${s.ssm_name}` }));
  const amOpts  = ams.map(a  => ({ value:a.id, label:`${a.am_code} — ${a.am_name}`   }));

  const filtered = rows.filter(r => {
    const matchSearch = !search ||
      r.sr_name?.toLowerCase().includes(search.toLowerCase()) ||
      r.sr_code?.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter==='all' || r.status===statusFilter;
    return matchSearch && matchStatus;
  });

  const validate = (d) => {
    const e = {};
    if (!d.sr_code.trim()) e.sr_code = 'Required';
    if (!d.sr_name.trim()) e.sr_name = 'Required';
    if (!d.cnic.trim())    e.cnic    = 'Required';
    return e;
  };

  const set = (k, v) => { setModal(m=>({...m, data:{...m.data,[k]:v}})); setErrors(e=>({...e,[k]:undefined})); };

  const handleSave = async () => {
    const e = validate(modal.data);
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    try {
      const res = modal.mode==='create' ? await api.createSR(modal.data) : await api.updateSR(modal.data);
      if (res.ok) { toast(`SR ${modal.mode==='create'?'created':'updated'}`, 'success'); setModal(m=>({...m,open:false})); load(); }
      else toast(res.error||'Save failed','error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    const res = await api.deleteSR(confirm.id);
    if (res.ok) { toast('SR deleted','success'); load(); }
    else toast(res.error||'Delete failed','error');
    setConfirm({open:false,id:null});
  };

  const columns = [
    { key:'sr_code',  label:'SR Code' },
    { key:'sr_name',  label:'SR Name' },
    { key:'cnic',     label:'CNIC' },
    { key:'contact_1',label:'Contact' },
    { key:'sm_code',  label:'SM Code' },
    { key:'ssm_code', label:'SSM Code' },
    { key:'status',   label:'Status', render: v=><span className={`badge badge-${v}`}>{v}</span> },
    { key:'no_of_policies', label:'Policies' },
    { key:'second_year_premium', label:'2nd Yr Prem', render: v=>`Rs. ${Number(v||0).toLocaleString()}` },
  ];

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">SR Register</h1><p className="page-subtitle">Sales Representative records</p></div>
        <div className="page-actions">
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="sr-search" className="search-input" placeholder="Search…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <select className="form-select" style={{width:120}} value={statusFilter} onChange={e=>setStatusFilter(e.target.value)}>
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
          <button id="btn-create-sr" className="btn btn-primary btn-sm" onClick={()=>setModal({open:true,mode:'create',data:{...EMPTY}})}>+ Add SR</button>
        </div>
      </div>

      <DataTable columns={columns} rows={filtered} loading={loading}
        actions={row=><>
          <button className="btn btn-ghost btn-sm" onClick={()=>setModal({open:true,mode:'edit',data:{...row}})}>✏️</button>
          <button className="btn btn-danger btn-sm" onClick={()=>setConfirm({open:true,id:row.id})}>🗑</button>
        </>}
      />

      <Modal open={modal.open} onClose={()=>setModal(m=>({...m,open:false}))}
        title={modal.mode==='create'?'Add SR':'Edit SR'} size="lg"
        footer={<>
          <button className="btn btn-secondary btn-sm" onClick={()=>setModal(m=>({...m,open:false}))}>Cancel</button>
          <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>{saving?<span className="spinner"/>:'Save'}</button>
        </>}
      >
        <div className="form-grid form-grid-2" style={{gap:14}}>
          {[['sr_code','SR Code',true],['sr_name','SR Name',true],['cnic','CNIC',true],['contact_1','Contact 1'],['contact_2','Contact 2']].map(([k,label,req])=>(
            <div key={k} className="form-group">
              <label className={`form-label${req?' required':''}`}>{label}</label>
              <input className={`form-input${errors[k]?' error':''}`} value={modal.data[k]||''} onChange={e=>set(k,e.target.value)} />
              {errors[k]&&<span className="form-error">{errors[k]}</span>}
            </div>
          ))}
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Address</label>
            <textarea className="form-textarea" value={modal.data.address||''} onChange={e=>set('address',e.target.value)} rows={2}/>
          </div>
          <div className="form-group">
            <label className="form-label">SM</label>
            <SearchableDropdown id="sr-sm" options={smOpts} value={modal.data.sm_id} onChange={v=>set('sm_id',v)} placeholder="Select SM…"/>
          </div>
          <div className="form-group">
            <label className="form-label">SSM</label>
            <SearchableDropdown id="sr-ssm" options={ssmOpts} value={modal.data.ssm_id} onChange={v=>set('ssm_id',v)} placeholder="Select SSM…"/>
          </div>
          <div className="form-group">
            <label className="form-label">Area Manager</label>
            <SearchableDropdown id="sr-am" options={amOpts} value={modal.data.am_id} onChange={v=>set('am_id',v)} placeholder="Select AM…"/>
          </div>
          <div className="form-group">
            <label className="form-label">Status</label>
            <select className="form-select" value={modal.data.status} onChange={e=>set('status',e.target.value)}>
              <option value="active">Active</option><option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={confirm.open} onClose={()=>setConfirm({open:false,id:null})} onConfirm={handleDelete}
        title="Delete SR" message="Are you sure? This action cannot be undone." />
    </div>
  );
}
