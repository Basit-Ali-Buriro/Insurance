import React, { useState } from 'react';
import api from '../lib/api.js';
import { useToast } from '../components/Toast.jsx';

export default function LoginPage({ onLogin }) {
  const toast = useToast();
  const [form,    setForm]    = useState({ username: '', password: '' });
  const [error,   setError]   = useState('');
  const [loading, setLoading] = useState(false);
  const [showPwd, setShowPwd] = useState(false);

  const handleChange = (e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }));
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.username.trim() || !form.password) {
      setError('Please enter your username and password.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await api.login({ username: form.username.trim(), password: form.password });
      if (res.ok) {
        toast('Login successful. Welcome back!', 'success');
        onLogin(res.user);
      } else {
        setError(res.error || 'Invalid credentials, please try again.');
      }
    } catch {
      setError('Connection error. Please restart the application.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        {/* Logo */}
        <div className="login-logo-wrap">
          <div className="login-logo-icon">
            <span style={{ fontSize: '1.5rem' }}>🛡</span>
          </div>
          <h1 className="login-title">Insurance PMS</h1>
          <p className="login-subtitle">Policy Records Management System</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} noValidate>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>

            <div className="form-group">
              <label className="form-label required" htmlFor="login-username">Username</label>
              <input
                id="login-username"
                name="username"
                type="text"
                className={`form-input${error ? ' error' : ''}`}
                placeholder="Enter your username"
                value={form.username}
                onChange={handleChange}
                autoFocus
                autoComplete="username"
                disabled={loading}
              />
            </div>

            <div className="form-group">
              <label className="form-label required" htmlFor="login-password">Password</label>
              <div style={{ position: 'relative' }}>
                <input
                  id="login-password"
                  name="password"
                  type={showPwd ? 'text' : 'password'}
                  className={`form-input${error ? ' error' : ''}`}
                  placeholder="Enter your password"
                  value={form.password}
                  onChange={handleChange}
                  autoComplete="current-password"
                  disabled={loading}
                  style={{ paddingRight: 40 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPwd(v => !v)}
                  style={{
                    position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
                    background: 'none', border: 'none', cursor: 'pointer',
                    color: 'var(--text-muted)', fontSize: '0.85rem', padding: 0,
                  }}
                  tabIndex={-1}
                  aria-label={showPwd ? 'Hide password' : 'Show password'}
                >
                  {showPwd ? '🙈' : '👁'}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div style={{
                background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)',
                borderRadius: 'var(--radius-sm)', padding: '9px 12px',
                fontSize: '0.78rem', color: 'var(--accent-red)',
                display: 'flex', alignItems: 'center', gap: 7,
              }}>
                <span>✕</span> {error}
              </div>
            )}

            <button
              id="btn-login"
              type="submit"
              className="btn btn-primary btn-lg"
              disabled={loading}
              style={{ marginTop: 4, width: '100%' }}
            >
              {loading ? <><span className="spinner" /> Authenticating…</> : 'Sign In'}
            </button>
          </div>
        </form>

        <p style={{ textAlign: 'center', fontSize: '0.68rem', color: 'var(--text-muted)', marginTop: 24 }}>
          Insurance Records Management System v1.0
        </p>
      </div>
    </div>
  );
}
