import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const EMPTY = { am_code:'', am_name:'', address:'', cnic:'', contact_1:'', contact_2:'', status:'active' };

function Badge({ v }) {
  return <span className={`badge badge-${v}`}>{v}</span>;
}

export default function AreaManager() {
  const toast = useToast();
  const [rows,    setRows]    = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');
  const [modal,   setModal]   = useState({ open:false, mode:'create', data:EMPTY });
  const [confirm, setConfirm] = useState({ open:false, id:null });
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try { setRows(await api.listAM()); }
    catch { toast('Failed to load Area Managers','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = rows.filter(r =>
    !search ||
    r.am_name?.toLowerCase().includes(search.toLowerCase()) ||
    r.am_code?.toLowerCase().includes(search.toLowerCase())
  );

  const validate = (d) => {
    const e = {};
    if (!d.am_code.trim())  e.am_code  = 'Required';
    if (!d.am_name.trim())  e.am_name  = 'Required';
    if (!d.cnic.trim())     e.cnic     = 'Required';
    return e;
  };

  const openCreate = () => setModal({ open:true, mode:'create', data:{...EMPTY} });
  const openEdit   = (row) => setModal({ open:true, mode:'edit', data:{...row} });

  const handleSave = async () => {
    const e = validate(modal.data);
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    try {
      const res = modal.mode === 'create'
        ? await api.createAM(modal.data)
        : await api.updateAM(modal.data);
      if (res.ok) { toast(`Area Manager ${modal.mode==='create'?'created':'updated'}`, 'success'); setModal(m=>({...m,open:false})); load(); }
      else toast(res.error || 'Save failed', 'error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    const res = await api.deleteAM(confirm.id);
    if (res.ok) { toast('Area Manager deleted','success'); load(); }
    else toast(res.error||'Delete failed','error');
    setConfirm({ open:false, id:null });
  };

  const set = (k, v) => { setModal(m=>({...m, data:{...m.data,[k]:v}})); setErrors(e=>({...e,[k]:undefined})); };

  const columns = [
    { key:'am_code',  label:'AM Code' },
    { key:'am_name',  label:'Name' },
    { key:'cnic',     label:'CNIC' },
    { key:'contact_1',label:'Contact' },
    { key:'status',   label:'Status', render: v => <Badge v={v} /> },
    { key:'no_of_ssms', label:'SSMs' },
    { key:'no_of_sms',  label:'SMs' },
    { key:'no_of_srs',  label:'SRs' },
    { key:'total_business', label:'Total Business', render: v => `Rs. ${Number(v||0).toLocaleString()}` },
  ];

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Area Manager</h1><p className="page-subtitle">Manage area managers and their hierarchies</p></div>
        <div className="page-actions">
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="am-search" className="search-input" placeholder="Search by name or code…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <button id="btn-create-am" className="btn btn-primary btn-sm" onClick={openCreate}>+ Add Area Manager</button>
        </div>
      </div>

      <DataTable columns={columns} rows={filtered} loading={loading}
        actions={row => (<>
          <button className="btn btn-ghost btn-sm" onClick={()=>openEdit(row)}>✏️ Edit</button>
          <button className="btn btn-danger btn-sm" onClick={()=>setConfirm({open:true,id:row.id})}>🗑</button>
        </>)}
      />

      {/* Form Modal */}
      <Modal open={modal.open} onClose={()=>setModal(m=>({...m,open:false}))} title={modal.mode==='create'?'Add Area Manager':'Edit Area Manager'} size="md"
        footer={<>
          <button className="btn btn-secondary btn-sm" onClick={()=>setModal(m=>({...m,open:false}))}>Cancel</button>
          <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>{saving?<span className="spinner"/>:'Save'}</button>
        </>}
      >
        <div className="form-grid form-grid-2" style={{gap:14}}>
          {[['am_code','AM Code',true],['am_name','AM Name',true],['cnic','CNIC',true],['contact_1','Contact 1'],['contact_2','Contact 2'],['address','Address']].map(([k,label,req])=>(
            <div key={k} className="form-group" style={k==='address'?{gridColumn:'1/-1'}:{}}>
              <label className={`form-label${req?' required':''}`}>{label}</label>
              {k==='address'
                ? <textarea className={`form-textarea${errors[k]?' error':''}`} value={modal.data[k]||''} onChange={e=>set(k,e.target.value)} rows={2} />
                : <input className={`form-input${errors[k]?' error':''}`} value={modal.data[k]||''} onChange={e=>set(k,e.target.value)} />
              }
              {errors[k] && <span className="form-error">{errors[k]}</span>}
            </div>
          ))}
          <div className="form-group">
            <label className="form-label">Status</label>
            <select className="form-select" value={modal.data.status} onChange={e=>set('status',e.target.value)}>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={confirm.open} onClose={()=>setConfirm({open:false,id:null})} onConfirm={handleDelete}
        title="Delete Area Manager" message="Are you sure you want to delete this record? This action cannot be undone." />
    </div>
  );
}
