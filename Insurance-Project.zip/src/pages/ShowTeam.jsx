import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const ROLE_TYPES = ['SR','SM','SSM'];

export default function ShowTeam() {
  const toast = useToast();
  const [roleFilter, setRoleFilter] = useState('SR');
  const [search, setSearch] = useState('');
  const [data, setData] = useState({ SR:[], SM:[], SSM:[] });
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [srs, sms, ssms] = await Promise.all([api.listSR(), api.listSM(), api.listSSM()]);
      setData({ SR: srs, SM: sms, SSM: ssms });
    } catch { toast('Failed to load team data','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const rawRows = data[roleFilter] || [];
  const filtered = rawRows.filter(r => {
    if (!search) return true;
    const name = r.sr_name || r.sm_name || r.ssm_name || '';
    const code = r.sr_code || r.sm_code || r.ssm_code || '';
    return name.toLowerCase().includes(search.toLowerCase()) || code.toLowerCase().includes(search.toLowerCase());
  });

  const srColumns = [
    { key:'sr_code',  label:'SR Code' },
    { key:'sr_name',  label:'SR Name' },
    { key:'cnic',     label:'CNIC' },
    { key:'contact_1',label:'Contact' },
    { key:'sm_code',  label:'SM Code' },
    { key:'ssm_code', label:'SSM Code' },
    { key:'am_code',  label:'AM Code' },
    { key:'status',   label:'Status', render: v=><span className={`badge badge-${v}`}>{v}</span> },
    { key:'no_of_policies', label:'Policies' },
    { key:'second_year_premium', label:'2nd Yr Prem', render: v=>`Rs. ${Number(v||0).toLocaleString()}` },
  ];

  const smColumns = [
    { key:'sm_code',  label:'SM Code' },
    { key:'sm_name',  label:'SM Name' },
    { key:'cnic',     label:'CNIC' },
    { key:'contact_1',label:'Contact' },
    { key:'ssm_code', label:'SSM Code' },
    { key:'am_code',  label:'AM Code' },
    { key:'status',   label:'Status', render: v=><span className={`badge badge-${v}`}>{v}</span> },
    { key:'no_of_srs', label:'SRs' },
    { key:'total_business', label:'Total Business', render: v=>`Rs. ${Number(v||0).toLocaleString()}` },
  ];

  const ssmColumns = [
    { key:'ssm_code', label:'SSM Code' },
    { key:'ssm_name', label:'SSM Name' },
    { key:'cnic',     label:'CNIC' },
    { key:'contact_1',label:'Contact' },
    { key:'am_code',  label:'AM Code' },
    { key:'status',   label:'Status', render: v=><span className={`badge badge-${v}`}>{v}</span> },
    { key:'no_of_sms', label:'SMs' },
    { key:'no_of_srs', label:'SRs' },
    { key:'total_business', label:'Total Business', render: v=>`Rs. ${Number(v||0).toLocaleString()}` },
  ];

  const columns = roleFilter==='SR' ? srColumns : roleFilter==='SM' ? smColumns : ssmColumns;

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Show Team</h1><p className="page-subtitle">Unified view of all SR, SM and SSM records</p></div>
        <div className="page-actions">
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="team-search" className="search-input" placeholder="Search by name or code…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <div className="toggle-group">
            {ROLE_TYPES.map(t => (
              <button key={t} id={`team-filter-${t}`} className={`toggle-btn${roleFilter===t?' active':''}`} onClick={()=>{ setRoleFilter(t); setSearch(''); }}>
                {t}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ marginBottom:12, fontSize:'0.78rem', color:'var(--text-muted)' }}>
        Showing <strong style={{color:'var(--text-secondary)'}}>{filtered.length}</strong> {roleFilter} records
      </div>

      <DataTable columns={columns} rows={filtered} loading={loading} emptyMsg={`No ${roleFilter} records found.`} />
    </div>
  );
}
