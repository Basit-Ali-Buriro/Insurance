import React, { useState, useEffect, useCallback } from 'react';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

function daysBadgeClass(days) {
  if (days <= 7)  return 'urgent';
  if (days <= 15) return 'soon';
  return 'normal';
}

export default function Notifications() {
  const toast = useToast();
  const [items,   setItems]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try { setItems(await api.listNotifications()); }
    catch { toast('Failed to load notifications','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const filtered = items.filter(item =>
    !search ||
    item.holder_name?.toLowerCase().includes(search.toLowerCase()) ||
    item.policy_no?.toLowerCase().includes(search.toLowerCase()) ||
    item.sr_code?.toLowerCase().includes(search.toLowerCase())
  );

  const handleWhatsApp = async (item) => {
    await api.openWhatsapp({
      phone:     item.contact_1,
      name:      item.holder_name,
      policyNo:  item.policy_no,
      dueDate:   item.due_date,
    });
    await api.markWhatsapp(item.id);
    toast('WhatsApp opened. Reminder marked as sent.','success');
    load();
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Notifications</h1>
          <p className="page-subtitle">Policies due within 30 days — send WhatsApp reminders</p>
        </div>
        <div className="page-actions">
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="notif-search" className="search-input" placeholder="Search by name, policy no, SR…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <button className="btn btn-ghost btn-sm" onClick={load}>↻ Refresh</button>
        </div>
      </div>

      {loading ? (
        <div style={{ display:'flex', justifyContent:'center', padding:60 }}>
          <span className="spinner" style={{width:32,height:32,borderWidth:3,borderTopColor:'var(--accent)'}}/>
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <div className="empty-state-icon">✅</div>
          <p>No policies due within 30 days. All clear!</p>
        </div>
      ) : (
        <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
          {filtered.map(item => {
            const days = Math.round(item.days_left ?? 0);
            return (
              <div key={item.id} className={`notif-card${item.whatsapp_sent ? ' sent':''}`}>
                <div style={{ display:'flex', alignItems:'flex-start', justifyContent:'space-between', gap:12 }}>
                  <div style={{ flex:1 }}>
                    <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:6 }}>
                      <span style={{ fontWeight:700, fontSize:'0.92rem' }}>{item.holder_name}</span>
                      <span className={`days-badge ${daysBadgeClass(days)}`}>
                        {days <= 0 ? 'Overdue!' : `Due in ${days} day${days!==1?'s':''}`}
                      </span>
                      {item.whatsapp_sent && (
                        <span className="badge badge-active" style={{fontSize:'0.62rem'}}>✓ Reminder Sent</span>
                      )}
                    </div>
                    <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:'4px 16px', fontSize:'0.77rem', color:'var(--text-secondary)' }}>
                      <span><span style={{color:'var(--text-muted)'}}>Policy No: </span>{item.policy_no}</span>
                      <span><span style={{color:'var(--text-muted)'}}>Contact: </span>{item.contact_1}</span>
                      <span><span style={{color:'var(--text-muted)'}}>Due Date: </span>{item.due_date}</span>
                      <span><span style={{color:'var(--text-muted)'}}>SR Code: </span>{item.sr_code || '—'}</span>
                      <span><span style={{color:'var(--text-muted)'}}>SR Name: </span>{item.sr_name || '—'}</span>
                    </div>
                    {item.whatsapp_sent && item.whatsapp_sent_at && (
                      <div style={{ fontSize:'0.68rem', color:'var(--text-muted)', marginTop:4 }}>
                        Sent at: {new Date(item.whatsapp_sent_at).toLocaleString()}
                      </div>
                    )}
                  </div>

                  <button
                    id={`btn-wa-${item.id}`}
                    className="btn btn-success btn-sm"
                    style={{ flexShrink:0 }}
                    onClick={() => handleWhatsApp(item)}
                    disabled={!item.contact_1}
                    title={!item.contact_1 ? 'No contact number on file' : 'Send WhatsApp reminder'}
                  >
                    💬 WhatsApp
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
