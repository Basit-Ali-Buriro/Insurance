import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import Modal, { ConfirmDialog } from '../components/Modal.jsx';
import SearchableDropdown from '../components/SearchableDropdown.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const EMPTY = { policy_no:'', holder_name:'', cnic:'', address:'', contact_1:'', contact_2:'', premium:'', issue_date:'', due_date:'', table_term:'', last_paid_date:'', sr_id:null, sm_id:null, ssm_id:null };

export default function PolicyRegister() {
  const toast = useToast();
  const [rows, setRows] = useState([]);
  const [srs,  setSRs]  = useState([]);
  const [sms,  setSMs]  = useState([]);
  const [ssms, setSSMs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search,  setSearch]  = useState('');
  const [modal,   setModal]   = useState({ open:false, mode:'create', data:EMPTY });
  const [confirm, setConfirm] = useState({ open:false, id:null });
  const [saving,  setSaving]  = useState(false);
  const [errors,  setErrors]  = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [r, sr, sm, ssm] = await Promise.all([api.listPolicies(), api.listSR(), api.listSM(), api.listSSM()]);
      setRows(r); setSRs(sr); setSMs(sm); setSSMs(ssm);
    } catch { toast('Failed to load policies','error'); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const srOpts  = srs.map(s  => ({ value:s.id, label:`${s.sr_code} — ${s.sr_name}`   }));
  const smOpts  = sms.map(s  => ({ value:s.id, label:`${s.sm_code} — ${s.sm_name}`   }));
  const ssmOpts = ssms.map(s => ({ value:s.id, label:`${s.ssm_code} — ${s.ssm_name}` }));

  const filtered = rows.filter(r =>
    !search ||
    r.holder_name?.toLowerCase().includes(search.toLowerCase()) ||
    r.policy_no?.toLowerCase().includes(search.toLowerCase()) ||
    r.sr_code?.toLowerCase().includes(search.toLowerCase()) ||
    r.sm_code?.toLowerCase().includes(search.toLowerCase())
  );

  const validate = (d) => {
    const e = {};
    if (!d.policy_no.trim())  e.policy_no  = 'Required';
    if (!d.holder_name.trim())e.holder_name = 'Required';
    if (!d.cnic.trim())       e.cnic        = 'Required';
    if (!d.premium || isNaN(d.premium)) e.premium = 'Valid number required';
    if (!d.issue_date)        e.issue_date  = 'Required';
    return e;
  };

  const set = (k, v) => { setModal(m=>({...m, data:{...m.data,[k]:v}})); setErrors(e=>({...e,[k]:undefined})); };

  const handleSave = async () => {
    const e = validate(modal.data);
    if (Object.keys(e).length) { setErrors(e); return; }
    setSaving(true);
    try {
      const res = modal.mode==='create' ? await api.createPolicy(modal.data) : await api.updatePolicy(modal.data);
      if (res.ok) { toast(`Policy ${modal.mode==='create'?'created':'updated'}`, 'success'); setModal(m=>({...m,open:false})); load(); }
      else toast(res.error||'Save failed','error');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    const res = await api.deletePolicy(confirm.id);
    if (res.ok) { toast('Policy deleted','success'); load(); }
    else toast(res.error||'Delete failed','error');
    setConfirm({open:false,id:null});
  };

  const columns = [
    { key:'policy_no',    label:'Policy No' },
    { key:'holder_name',  label:'Holder Name' },
    { key:'cnic',         label:'CNIC' },
    { key:'contact_1',    label:'Contact' },
    { key:'premium',      label:'Premium', render: v=>`Rs. ${Number(v||0).toLocaleString()}` },
    { key:'issue_date',   label:'Issue Date' },
    { key:'due_date',     label:'Due Date' },
    { key:'last_paid_date',label:'Last Paid' },
    { key:'sr_code',      label:'SR Code' },
    { key:'sm_code',      label:'SM Code' },
  ];

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Policy Register</h1><p className="page-subtitle">Insurance policy records</p></div>
        <div className="page-actions">
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="pol-search" className="search-input" placeholder="Search by name, policy no, SR/SM code…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <button id="btn-create-policy" className="btn btn-primary btn-sm" onClick={()=>setModal({open:true,mode:'create',data:{...EMPTY}})}>+ Add Policy</button>
        </div>
      </div>

      <DataTable columns={columns} rows={filtered} loading={loading}
        actions={row=><>
          <button className="btn btn-ghost btn-sm" onClick={()=>setModal({open:true,mode:'edit',data:{...row}})}>✏️</button>
          <button className="btn btn-danger btn-sm" onClick={()=>setConfirm({open:true,id:row.id})}>🗑</button>
        </>}
      />

      <Modal open={modal.open} onClose={()=>setModal(m=>({...m,open:false}))}
        title={modal.mode==='create'?'Add Policy':'Edit Policy'} size="lg"
        footer={<>
          <button className="btn btn-secondary btn-sm" onClick={()=>setModal(m=>({...m,open:false}))}>Cancel</button>
          <button className="btn btn-primary btn-sm" onClick={handleSave} disabled={saving}>{saving?<span className="spinner"/>:'Save'}</button>
        </>}
      >
        <div className="form-grid form-grid-2" style={{gap:14}}>
          {[
            ['policy_no','Policy Number',true,'text'],
            ['holder_name','Policy Holder Name',true,'text'],
            ['cnic','CNIC',true,'text'],
            ['contact_1','Contact No 1',false,'text'],
            ['contact_2','Contact No 2',false,'text'],
            ['premium','Premium',true,'number'],
            ['issue_date','Issue Date',true,'date'],
            ['due_date','Due Date',false,'date'],
            ['table_term','Table Term',false,'text'],
            ['last_paid_date','Last Paid Date',false,'date'],
          ].map(([k,label,req,type])=>(
            <div key={k} className="form-group">
              <label className={`form-label${req?' required':''}`}>{label}</label>
              <input type={type} className={`form-input${errors[k]?' error':''}`} value={modal.data[k]||''} onChange={e=>set(k,e.target.value)} />
              {errors[k]&&<span className="form-error">{errors[k]}</span>}
            </div>
          ))}
          <div className="form-group" style={{gridColumn:'1/-1'}}>
            <label className="form-label">Address</label>
            <textarea className="form-textarea" value={modal.data.address||''} onChange={e=>set('address',e.target.value)} rows={2}/>
          </div>
          <div className="form-group">
            <label className="form-label">SR</label>
            <SearchableDropdown id="pol-sr" options={srOpts} value={modal.data.sr_id} onChange={v=>set('sr_id',v)} placeholder="Select SR…"/>
          </div>
          <div className="form-group">
            <label className="form-label">SM</label>
            <SearchableDropdown id="pol-sm" options={smOpts} value={modal.data.sm_id} onChange={v=>set('sm_id',v)} placeholder="Select SM…"/>
          </div>
          <div className="form-group">
            <label className="form-label">SSM</label>
            <SearchableDropdown id="pol-ssm" options={ssmOpts} value={modal.data.ssm_id} onChange={v=>set('ssm_id',v)} placeholder="Select SSM…"/>
          </div>
        </div>
      </Modal>

      <ConfirmDialog open={confirm.open} onClose={()=>setConfirm({open:false,id:null})} onConfirm={handleDelete}
        title="Delete Policy" message="Are you sure? This action cannot be undone." />
    </div>
  );
}
