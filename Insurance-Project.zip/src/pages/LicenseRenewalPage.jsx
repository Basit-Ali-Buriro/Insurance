import React, { useState } from 'react';
import api from '../lib/api.js';
import { useToast } from '../components/Toast.jsx';

export default function LicenseRenewalPage({ onRenewed }) {
  const toast   = useToast();
  const [key,     setKey]     = useState('');
  const [error,   setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!key.trim()) { setError('Please enter the activation key.'); return; }
    setLoading(true);
    setError('');
    try {
      const ok = await api.licenseRenew(key.trim());
      if (ok) {
        toast('License renewed successfully. Welcome back!', 'success');
        onRenewed();
      } else {
        setError('Invalid Key. Please contact your software provider.');
      }
    } catch {
      setError('An error occurred. Please restart and try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-card">
        <div className="login-logo-wrap">
          <div className="login-logo-icon" style={{ background: 'linear-gradient(135deg,#ef4444,#dc2626)' }}>
            <span style={{ fontSize: '1.5rem' }}>🔒</span>
          </div>
          <h1 className="login-title">License Expired</h1>
          <p className="login-subtitle" style={{ color: 'var(--accent-red)' }}>
            Your software license has expired.<br />Please contact your software provider.
          </p>
        </div>

        <form onSubmit={handleSubmit} noValidate>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div className="form-group">
              <label className="form-label required" htmlFor="renewal-key">Activation Key</label>
              <input
                id="renewal-key"
                type="text"
                className={`form-input${error ? ' error' : ''}`}
                placeholder="Enter the activation key provided by your provider"
                value={key}
                onChange={e => { setKey(e.target.value); setError(''); }}
                disabled={loading}
                autoFocus
                style={{ fontFamily: 'var(--font-mono)', letterSpacing: '0.05em' }}
              />
            </div>

            {error && (
              <div style={{
                background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)',
                borderRadius: 'var(--radius-sm)', padding: '9px 12px',
                fontSize: '0.78rem', color: 'var(--accent-red)',
                display: 'flex', alignItems: 'center', gap: 7,
              }}>
                <span>✕</span> {error}
              </div>
            )}

            <button
              id="btn-activate"
              type="submit"
              className="btn btn-primary btn-lg"
              disabled={loading}
              style={{ width: '100%' }}
            >
              {loading ? <><span className="spinner" /> Validating…</> : 'Activate License'}
            </button>
          </div>
        </form>

        <p style={{ textAlign: 'center', fontSize: '0.68rem', color: 'var(--text-muted)', marginTop: 24 }}>
          Insurance Records Management System v1.0
        </p>
      </div>
    </div>
  );
}
