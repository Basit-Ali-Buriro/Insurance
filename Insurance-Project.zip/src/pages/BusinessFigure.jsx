import React, { useState, useEffect, useCallback } from 'react';
import DataTable from '../components/DataTable.jsx';
import { useToast } from '../components/Toast.jsx';
import api from '../lib/api.js';

const ROLES = ['SR','SM','SSM'];

function today() { return new Date().toISOString().split('T')[0]; }
function monthStart() {
  const d = new Date(); d.setDate(1);
  return d.toISOString().split('T')[0];
}
function fmt(n) { return `Rs. ${Number(n||0).toLocaleString()}`; }

export default function BusinessFigure() {
  const toast = useToast();
  const [role,    setRole]    = useState('SR');
  const [from,    setFrom]    = useState(monthStart());
  const [to,      setTo]      = useState(today());
  const [rows,    setRows]    = useState([]);
  const [loading, setLoading] = useState(false);
  const [search,  setSearch]  = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      let data;
      if (role==='SR')       data = await api.srFigure({ from, to });
      else if (role==='SM')  data = await api.smFigure({ from, to });
      else                   data = await api.ssmFigure({ from, to });
      setRows(data || []);
    } catch { toast('Failed to load business figures','error'); }
    finally { setLoading(false); }
  }, [role, from, to]);

  useEffect(() => { load(); }, [load]);

  const filtered = rows.filter(r => {
    if (!search) return true;
    const name = r.sr_name || r.sm_name || r.ssm_name || '';
    const code = r.sr_code || r.sm_code || r.ssm_code || '';
    return name.toLowerCase().includes(search.toLowerCase()) || code.toLowerCase().includes(search.toLowerCase());
  });

  // Grand totals
  const grandTotal = filtered.reduce((acc, r) => ({
    total_business:    acc.total_business    + (r.total_business||0),
    no_of_policies:    acc.no_of_policies    + (r.no_of_policies||0),
    second_year_premium: acc.second_year_premium + (r.second_year_premium||0),
  }), { total_business:0, no_of_policies:0, second_year_premium:0 });

  const srCols = [
    { key:'sr_code',           label:'SR Code' },
    { key:'sr_name',           label:'SR Name' },
    { key:'sm_code',           label:'SM Code' },
    { key:'total_business',    label:'Total Business',    render: v=>fmt(v) },
    { key:'no_of_policies',    label:'No of Policies' },
    { key:'second_year_premium',label:'2nd Year Premium', render: v=>fmt(v) },
  ];
  const smCols = [
    { key:'sm_code',           label:'SM Code' },
    { key:'sm_name',           label:'SM Name' },
    { key:'ssm_code',          label:'SSM Code' },
    { key:'total_business',    label:'Total Business',    render: v=>fmt(v) },
    { key:'no_of_policies',    label:'No of Policies' },
    { key:'no_of_srs_added',   label:'SRs Added' },
    { key:'second_year_premium',label:'2nd Year Premium', render: v=>fmt(v) },
  ];
  const ssmCols = [
    { key:'ssm_code',          label:'SSM Code' },
    { key:'ssm_name',          label:'SSM Name' },
    { key:'am_name',           label:'Area Manager' },
    { key:'total_business',    label:'Total Business',    render: v=>fmt(v) },
    { key:'no_of_policies',    label:'No of Policies' },
    { key:'no_of_srs_added',   label:'SRs Added' },
    { key:'no_of_sms_added',   label:'SMs Added' },
    { key:'second_year_premium',label:'2nd Year Premium', render: v=>fmt(v) },
  ];

  const columns = role==='SR' ? srCols : role==='SM' ? smCols : ssmCols;

  // Append grand total row
  const displayRows = filtered.length ? [
    ...filtered,
    {
      id: '__grand__',
      sr_code:'', sm_code:'', ssm_code:'',
      sr_name:'GRAND TOTAL', sm_name:'GRAND TOTAL', ssm_name:'GRAND TOTAL',
      am_name:'', ssm_code_ref:'', sm_code_ref:'',
      total_business:    grandTotal.total_business,
      no_of_policies:    grandTotal.no_of_policies,
      no_of_srs_added:   '', no_of_sms_added:'',
      second_year_premium: grandTotal.second_year_premium,
    }
  ] : [];

  return (
    <div>
      <div className="page-header">
        <div><h1 className="page-title">Business Figure</h1><p className="page-subtitle">Performance analytics by date range and role</p></div>
      </div>

      {/* Controls */}
      <div className="card card-sm" style={{ display:'flex', alignItems:'center', gap:16, marginBottom:20, flexWrap:'wrap' }}>
        <div className="form-group" style={{ flexDirection:'row', alignItems:'center', gap:8, marginBottom:0 }}>
          <label className="form-label" style={{whiteSpace:'nowrap',marginBottom:0}}>From</label>
          <input id="bf-from" type="date" className="form-input" style={{width:160}} value={from} onChange={e=>setFrom(e.target.value)} />
        </div>
        <div className="form-group" style={{ flexDirection:'row', alignItems:'center', gap:8, marginBottom:0 }}>
          <label className="form-label" style={{whiteSpace:'nowrap',marginBottom:0}}>To</label>
          <input id="bf-to" type="date" className="form-input" style={{width:160}} value={to} onChange={e=>setTo(e.target.value)} />
        </div>
        <button id="btn-bf-generate" className="btn btn-primary btn-sm" onClick={load}>Generate</button>
        <button id="btn-bf-reset" className="btn btn-secondary btn-sm" onClick={()=>{ setFrom(monthStart()); setTo(today()); }}>Reset</button>

        <div style={{ marginLeft:'auto', display:'flex', gap:8, alignItems:'center' }}>
          <div className="search-bar-wrap">
            <span className="search-icon">🔍</span>
            <input id="bf-search" className="search-input" placeholder="Search…" value={search} onChange={e=>setSearch(e.target.value)} />
          </div>
          <div className="toggle-group">
            {ROLES.map(r=>(
              <button key={r} id={`bf-role-${r}`} className={`toggle-btn${role===r?' active':''}`} onClick={()=>{setRole(r);setSearch('');}}>
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Summary strip */}
      {!loading && filtered.length > 0 && (
        <div style={{ display:'flex', gap:14, marginBottom:16 }}>
          {[
            ['Total Business', fmt(grandTotal.total_business), 'var(--accent-green)'],
            ['Total Policies', grandTotal.no_of_policies, 'var(--accent)'],
            ['2nd Year Premium', fmt(grandTotal.second_year_premium), 'var(--accent-purple)'],
          ].map(([label,val,color])=>(
            <div key={label} className="card card-sm" style={{flex:1}}>
              <div style={{fontSize:'0.7rem',color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.05em'}}>{label}</div>
              <div style={{fontSize:'1.2rem',fontWeight:700,color,marginTop:4}}>{val}</div>
            </div>
          ))}
        </div>
      )}

      {/* Table with grand-total row styling */}
      <div className="table-wrapper">
        <table className="data-table" style={{width:'100%'}}>
          <thead>
            <tr>{columns.map(c=><th key={c.key}>{c.label}</th>)}</tr>
          </thead>
          <tbody>
            {loading
              ? Array.from({length:4}).map((_,i)=>(
                <tr key={i}>{columns.map(c=>(
                  <td key={c.key}><div style={{height:14,background:'var(--bg-elevated)',borderRadius:4,animation:'pulse 1.5s infinite',width:'80%'}}/></td>
                ))}</tr>
              ))
              : displayRows.length
                ? displayRows.map((row,idx)=>(
                  <tr key={row.id??idx} className={row.id==='__grand__'?'grand-total-row':''}>
                    {columns.map(c=><td key={c.key}>{c.render ? c.render(row[c.key],row) : (row[c.key]??'—')}</td>)}
                  </tr>
                ))
                : <tr><td colSpan={columns.length} style={{textAlign:'center',padding:'40px',color:'var(--text-muted)'}}>No data for selected range</td></tr>
            }
          </tbody>
        </table>
      </div>
    </div>
  );
}
