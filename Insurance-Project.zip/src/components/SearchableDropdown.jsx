import React, { useState, useRef, useEffect } from 'react';

/**
 * Searchable dropdown that filters a list by label.
 * Props: options[{value, label}], value, onChange, placeholder, id, disabled
 */
export default function SearchableDropdown({ options = [], value, onChange, placeholder = 'Search…', id, disabled }) {
  const [query,  setQuery]  = useState('');
  const [open,   setOpen]   = useState(false);
  const wrapRef = useRef(null);

  const selected = options.find(o => o.value === value);

  // Close on outside click
  useEffect(() => {
    const handler = (e) => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const filtered = options.filter(o =>
    !query || o.label.toLowerCase().includes(query.toLowerCase())
  );

  const handleSelect = (opt) => {
    onChange(opt.value);
    setQuery('');
    setOpen(false);
  };

  const handleClear = (e) => {
    e.stopPropagation();
    onChange(null);
    setQuery('');
  };

  return (
    <div className="sd-wrapper" ref={wrapRef} id={id}>
      <div
        className="form-input"
        style={{ display:'flex', alignItems:'center', cursor: disabled ? 'not-allowed' : 'pointer', userSelect:'none', opacity: disabled ? 0.5 : 1 }}
        onClick={() => { if (!disabled) setOpen(v => !v); }}
      >
        {open ? (
          <input
            className="sd-search-input"
            autoFocus
            value={query}
            onChange={e => { setQuery(e.target.value); }}
            onClick={e => e.stopPropagation()}
            placeholder={placeholder}
            style={{ border:'none', background:'transparent', outline:'none', flex:1, color:'var(--text-primary)', fontFamily:'var(--font)', fontSize:'0.82rem' }}
          />
        ) : (
          <span style={{ flex:1, color: selected ? 'var(--text-primary)' : 'var(--text-muted)', fontSize:'0.82rem' }}>
            {selected?.label ?? placeholder}
          </span>
        )}
        {value && !disabled && (
          <span onClick={handleClear} style={{ marginLeft:6, color:'var(--text-muted)', cursor:'pointer', fontSize:'0.8rem' }}>✕</span>
        )}
        <span style={{ marginLeft:4, color:'var(--text-muted)', fontSize:'0.7rem' }}>{open ? '▲' : '▼'}</span>
      </div>

      {open && (
        <div className="sd-list">
          {filtered.length === 0
            ? <div className="sd-empty">No matches found</div>
            : filtered.map(opt => (
              <div
                key={opt.value}
                className={`sd-item${opt.value === value ? ' selected' : ''}`}
                onClick={() => handleSelect(opt)}
              >
                {opt.label}
              </div>
            ))
          }
        </div>
      )}
    </div>
  );
}
