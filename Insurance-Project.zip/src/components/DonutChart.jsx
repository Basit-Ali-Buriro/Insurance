import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const COLORS = {
  achieved: '#3b82f6',
  remaining: '#1e2d44',
};

export default function DonutChart({ title, achieved, target, color = '#3b82f6', id, onEditTarget }) {
  const pct     = target > 0 ? Math.min((achieved / target) * 100, 100) : 0;
  const data    = [
    { name: 'Achieved', value: Math.max(pct, 0.5) },
    { name: 'Remaining', value: Math.max(100 - pct, 0) },
  ];

  const [editing, setEditing] = React.useState(false);
  const [editVal, setEditVal] = React.useState('');

  const startEdit = () => {
    setEditVal(String(target || ''));
    setEditing(true);
  };
  const commitEdit = () => {
    const val = parseFloat(editVal);
    if (!isNaN(val) && val >= 0) onEditTarget?.(val);
    setEditing(false);
  };

  return (
    <div className="card" style={{ display:'flex', flexDirection:'column', alignItems:'center', gap:12, flex:1 }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, width:'100%' }}>
        <span style={{ fontWeight:600, fontSize:'0.85rem', color:'var(--text-secondary)' }}>{title}</span>
        <div className="inline-edit" style={{ marginLeft:'auto' }}>
          {editing ? (
            <>
              <input
                id={`target-input-${id}`}
                className="inline-edit-input"
                value={editVal}
                onChange={e => setEditVal(e.target.value)}
                onKeyDown={e => { if (e.key==='Enter') commitEdit(); if (e.key==='Escape') setEditing(false); }}
                autoFocus
                type="number"
                min="0"
              />
              <button className="btn btn-primary btn-sm" onClick={commitEdit}>✓</button>
            </>
          ) : (
            <button
              id={`btn-edit-target-${id}`}
              className="btn btn-ghost btn-sm"
              onClick={startEdit}
              title="Click to set target"
            >
              Target: {target > 0 ? `Rs. ${target.toLocaleString()}` : 'Set'}  ✏️
            </button>
          )}
        </div>
      </div>

      <ResponsiveContainer width="100%" height={140}>
        <PieChart>
          <Pie
            data={data}
            cx="50%" cy="50%"
            innerRadius={45} outerRadius={65}
            startAngle={90} endAngle={-270}
            dataKey="value"
            strokeWidth={0}
          >
            <Cell fill={color} />
            <Cell fill={COLORS.remaining} />
          </Pie>
          <Tooltip
            formatter={(val, name) => [name === 'Achieved' ? `${pct.toFixed(1)}%` : `${(100-pct).toFixed(1)}%`, name]}
            contentStyle={{ background:'var(--bg-elevated)', border:'1px solid var(--border)', borderRadius:8, fontSize:'0.75rem' }}
          />
        </PieChart>
      </ResponsiveContainer>

      <div style={{ textAlign:'center' }}>
        <div style={{ fontSize:'1.6rem', fontWeight:800, color }}>{pct.toFixed(1)}%</div>
        <div style={{ fontSize:'0.72rem', color:'var(--text-muted)', marginTop:2 }}>
          Rs. {achieved.toLocaleString()} / Rs. {target.toLocaleString()}
        </div>
      </div>
    </div>
  );
}
