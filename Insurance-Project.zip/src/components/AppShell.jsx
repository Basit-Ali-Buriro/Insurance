import React, { lazy, Suspense } from 'react';
import Sidebar from './Sidebar.jsx';

// Lazy-load pages for faster first paint
const Dashboard       = lazy(() => import('../pages/Dashboard.jsx'));
const ProposerRegister= lazy(() => import('../pages/ProposerRegister.jsx'));
const PolicyRegister  = lazy(() => import('../pages/PolicyRegister.jsx'));
const SRRegister      = lazy(() => import('../pages/SRRegister.jsx'));
const SMRecruitment   = lazy(() => import('../pages/SMRecruitment.jsx'));
const SSMRecruitment  = lazy(() => import('../pages/SSMRecruitment.jsx'));
const AreaManager     = lazy(() => import('../pages/AreaManager.jsx'));
const ShowTeam        = lazy(() => import('../pages/ShowTeam.jsx'));
const BusinessFigure  = lazy(() => import('../pages/BusinessFigure.jsx'));
const Notifications   = lazy(() => import('../pages/Notifications.jsx'));
const Settings        = lazy(() => import('../pages/Settings.jsx'));
const UsersPage       = lazy(() => import('../pages/UsersPage.jsx'));

const PAGE_MAP = {
  dashboard:      { component: Dashboard,         label: 'Dashboard' },
  proposer:       { component: ProposerRegister,  label: 'Proposer Register' },
  policy:         { component: PolicyRegister,    label: 'Policy Register' },
  sr:             { component: SRRegister,        label: 'SR Register' },
  sm:             { component: SMRecruitment,     label: 'SM Recruitment' },
  ssm:            { component: SSMRecruitment,    label: 'SSM Recruitment' },
  areamanager:    { component: AreaManager,       label: 'Area Manager' },
  showteam:       { component: ShowTeam,          label: 'Show Team' },
  businessfigure: { component: BusinessFigure,    label: 'Business Figure' },
  notifications:  { component: Notifications,     label: 'Notifications' },
  settings:       { component: Settings,          label: 'Settings' },
  users:          { component: UsersPage,         label: 'Users' },
};

const Spinner = () => (
  <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '100%', color: 'var(--text-muted)' }}>
    <span className="spinner" style={{ width: 28, height: 28, borderWidth: 3 }} />
  </div>
);

export default function AppShell({ user, licenseInfo, activePage, onNavigate, onLogout, onProfileUpdate }) {
  const PageEntry  = PAGE_MAP[activePage] ?? PAGE_MAP.dashboard;
  const PageComp   = PageEntry.component;
  // Guard: only developer can access users page
  const SafeComp   = activePage === 'users' && user?.role !== 'developer' ? Dashboard : PageComp;

  const showBanner = licenseInfo?.status === 'expiring' || licenseInfo?.status === 'expired';
  const isUrgent   = licenseInfo?.daysLeft <= 7;

  return (
    <div className="app-layout">
      <Sidebar
        user={user}
        activePage={activePage}
        onNavigate={onNavigate}
        onLogout={onLogout}
      />

      <div className="main-content">
        {/* License warning banner */}
        {showBanner && (
          <div className={`license-banner ${isUrgent ? 'danger' : 'warning'}`}>
            <span>{isUrgent ? '🔴' : '⚠️'}</span>
            {isUrgent
              ? `Your software license expires in ${licenseInfo.daysLeft} day(s). Immediate renewal required.`
              : `Your software license expires in ${licenseInfo.daysLeft} day(s). Please contact your software provider to renew.`}
          </div>
        )}

        {/* Breadcrumb */}
        <div className="breadcrumb">
          Insurance PMS <span>›</span> <span>{PageEntry.label}</span>
        </div>

        {/* Active page */}
        <div className="page-wrapper">
          <Suspense fallback={<Spinner />}>
            <SafeComp user={user} onNavigate={onNavigate} onProfileUpdate={onProfileUpdate} />
          </Suspense>
        </div>
      </div>
    </div>
  );
}
