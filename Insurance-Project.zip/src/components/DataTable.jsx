import React, { useState } from 'react';

const PAGE_SIZE = 10;

/**
 * Reusable paginated data table.
 * Props: columns[{key,label,render}], rows[], actions(row)=>JSX, loading, emptyMsg
 */
export default function DataTable({ columns, rows = [], actions, loading, emptyMsg = 'No records found.' }) {
  const [page, setPage] = useState(1);
  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const slice = rows.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Reset to page 1 when rows change
  React.useEffect(() => { setPage(1); }, [rows.length]);

  if (loading) {
    return (
      <div className="table-wrapper">
        <table className="data-table">
          <thead>
            <tr>
              {columns.map(c => <th key={c.key}>{c.label}</th>)}
              {actions && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {Array.from({ length: 5 }).map((_, i) => (
              <tr key={i}>
                {columns.map(c => (
                  <td key={c.key}>
                    <div style={{ height:14, background:'var(--bg-elevated)', borderRadius:4, animation:'pulse 1.5s infinite', width:'80%' }} />
                  </td>
                ))}
                {actions && <td />}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }

  if (!rows.length) {
    return (
      <div className="table-wrapper">
        <div className="empty-state">
          <div className="empty-state-icon">📭</div>
          <p>{emptyMsg}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="table-wrapper">
      <table className="data-table">
        <thead>
          <tr>
            {columns.map(c => <th key={c.key}>{c.label}</th>)}
            {actions && <th style={{ width: 130 }}>Actions</th>}
          </tr>
        </thead>
        <tbody>
          {slice.map((row, idx) => (
            <tr key={row.id ?? idx}>
              {columns.map(c => (
                <td key={c.key}>
                  {c.render ? c.render(row[c.key], row) : (row[c.key] ?? '—')}
                </td>
              ))}
              {actions && <td><div className="actions-cell">{actions(row)}</div></td>}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="pagination">
          <span className="pagination-info">
            Showing {(page-1)*PAGE_SIZE+1}–{Math.min(page*PAGE_SIZE, rows.length)} of {rows.length}
          </span>
          <button className="page-btn" onClick={() => setPage(1)} disabled={page===1}>«</button>
          <button className="page-btn" onClick={() => setPage(p=>p-1)} disabled={page===1}>‹</button>
          {Array.from({ length: totalPages }, (_, i) => i+1)
            .filter(p => Math.abs(p-page) <= 2)
            .map(p => (
              <button key={p} className={`page-btn${p===page?' active':''}`} onClick={() => setPage(p)}>{p}</button>
            ))}
          <button className="page-btn" onClick={() => setPage(p=>p+1)} disabled={page===totalPages}>›</button>
          <button className="page-btn" onClick={() => setPage(totalPages)} disabled={page===totalPages}>»</button>
        </div>
      )}
    </div>
  );
}
