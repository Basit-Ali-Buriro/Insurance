import React, { useState, useEffect } from 'react';
import api from '../lib/api.js';

const PAGES = [
  { key: 'dashboard',        label: 'Dashboard',         icon: '⊞' },
  { key: 'proposer',         label: 'Proposer Register',  icon: '📋' },
  { key: 'policy',           label: 'Policy Register',    icon: '📄' },
  { key: 'sr',               label: 'SR Register',        icon: '👤' },
  { key: 'sm',               label: 'SM Recruitment',     icon: '👥' },
  { key: 'ssm',              label: 'SSM Recruitment',    icon: '🏆' },
  { key: 'areamanager',      label: 'Area Manager',       icon: '🗺' },
  { key: 'showteam',         label: 'Show Team',          icon: '📊' },
  { key: 'businessfigure',   label: 'Business Figure',    icon: '💹' },
  { key: 'notifications',    label: 'Notifications',      icon: '🔔' },
  { key: 'settings',         label: 'Settings',           icon: '⚙' },
  { key: 'users',            label: 'Users',              icon: '🛡',  devOnly: true },
];

export default function Sidebar({ user, activePage, onNavigate, onLogout }) {
  const [notifCount, setNotifCount] = useState(0);

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const c = await api.notificationCount();
        if (mounted) setNotifCount(c || 0);
      } catch { /* silent */ }
    };
    load();
    const interval = setInterval(load, 30_000);
    return () => { mounted = false; clearInterval(interval); };
  }, []);

  // Refresh badge immediately when user opens Notifications page
  useEffect(() => {
    if (activePage === 'notifications') {
      api.notificationCount().then(c => setNotifCount(c || 0)).catch(() => {});
    }
  }, [activePage]);

  const visiblePages = PAGES.filter(p => !p.devOnly || user?.role === 'developer');

  return (
    <aside className="sidebar" role="navigation" aria-label="Main navigation">
      {/* Logo */}
      <div className="sidebar-logo">
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 34, height: 34, borderRadius: 8,
            background: 'linear-gradient(135deg, #3b82f6, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '1rem', flexShrink: 0,
          }}>🛡</div>
          <div>
            <div className="sidebar-logo-title">Insurance PMS</div>
            <div className="sidebar-logo-sub">Records Management</div>
          </div>
        </div>
      </div>

      {/* Logged-in user */}
      {user && (
        <div className="sidebar-user">
          <div className="sidebar-user-name">{user.name}</div>
          <span className={`role-badge ${user.role}`}>{user.role}</span>
        </div>
      )}

      {/* Navigation */}
      <nav className="sidebar-nav">
        {visiblePages.map(p => (
          <button
            key={p.key}
            id={`nav-${p.key}`}
            className={`nav-btn${activePage === p.key ? ' active' : ''}`}
            onClick={() => onNavigate(p.key)}
            title={p.label}
          >
            <span className="nav-icon">{p.icon}</span>
            <span>{p.label}</span>
            {p.key === 'notifications' && notifCount > 0 && (
              <span className="nav-badge">{notifCount > 99 ? '99+' : notifCount}</span>
            )}
          </button>
        ))}
      </nav>

      {/* Logout */}
      <div className="sidebar-bottom">
        <button className="logout-btn" id="btn-logout" onClick={onLogout}>
          <span>⏻</span>
          <span>Logout</span>
        </button>
      </div>
    </aside>
  );
}
