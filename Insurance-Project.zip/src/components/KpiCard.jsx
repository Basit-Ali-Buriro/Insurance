import React from 'react';

/**
 * KPI card with trend indicator.
 * Props: title, value, icon, trend(%), onClick, badgeLabel, badgeType
 */
export default function KpiCard({ title, value, icon, trend, onClick, badgeLabel, badgeType = 'info', loading }) {
  const trendUp = trend >= 0;
  return (
    <div
      className={`card${onClick ? ' kpi-clickable' : ''}`}
      onClick={onClick}
      id={`kpi-${title?.toLowerCase().replace(/\s+/g,'-')}`}
      style={{ display:'flex', flexDirection:'column', gap:10, minHeight:110 }}
    >
      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
        <span className="stat-label">{title}</span>
        <span style={{ fontSize:'1.3rem', opacity:0.7 }}>{icon}</span>
      </div>

      {loading
        ? <div style={{ height:36, background:'var(--bg-elevated)', borderRadius:'var(--radius-sm)', animation:'pulse 1.5s infinite' }} />
        : <div className="stat-number">{typeof value === 'number' ? value.toLocaleString() : (value ?? '—')}</div>
      }

      <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:'auto' }}>
        {trend !== undefined && (
          <span className={`trend ${trendUp ? 'up' : 'down'}`}>
            {trendUp ? '↑' : '↓'} {Math.abs(trend).toFixed(1)}% vs last month
          </span>
        )}
        {badgeLabel && <span className={`badge badge-${badgeType}`}>{badgeLabel}</span>}
        {onClick && <span style={{ fontSize:'0.68rem', color:'var(--accent)', marginLeft:'auto' }}>View all →</span>}
      </div>
    </div>
  );
}
